package com.example.grocerystore;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;

public class GroceryItemActivity extends AppCompatActivity {

    private TextView txtName, txtPrice, txtDescription, txtAvailability;
    private ImageView itemImage;
    private Button btnAddToCart;

    private ImageView firstFilledStar, secondFilledStar, thirdFilledStar, firstEmptyStar, secondEmptyStar, thirdEmptyStar;
    private RecyclerView reviewsRecView;

    private ReviewsAdapter adapter;

    private RelativeLayout addReviewRelLayout;

    private int currentRate = 0;

    private GroceryItem incomingItem;
    private Utils utils;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grocery_item);

        initViews();
        Intent intent = getIntent();
        try {
            incomingItem = intent.getParcelableExtra("item");
            setViewsValues();
        }catch (NullPointerException e) {
            e.printStackTrace();
        }

    }

    private void setViewsValues() {
        txtName.setText(incomingItem.getName());
        txtPrice.setText(String.valueOf("Rs"+incomingItem.getPrice()));
        txtAvailability.setText(incomingItem.getAvailableAmount() + " number(s) available");
        Glide.with(this)
                .asBitmap()
                .load(incomingItem.getImageUrl())
                .into(itemImage);

        btnAddToCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //TODO
            }
        });
        //TODO:Stars situation

        addReviewRelLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

    }

    private void initViews() {
        txtName = (TextView) findViewById(R.id.txtName);
        txtPrice = (TextView) findViewById(R.id.txtPrice);
        txtDescription = (TextView) findViewById(R.id.txtDesc);
        txtAvailability = (TextView) findViewById(R.id.txtAvailability);

        itemImage = (ImageView) findViewById(R.id.itemImage);

        btnAddToCart = (Button) findViewById(R.id.btnAddToCart);

        firstFilledStar = (ImageView) findViewById(R.id.firstFilledStar);
        secondFilledStar = (ImageView) findViewById(R.id.secondFilledStar);
        thirdFilledStar = (ImageView) findViewById(R.id.thirdFilledStar);
        firstEmptyStar = (ImageView) findViewById(R.id.firstEmptyStar);
        secondEmptyStar = (ImageView) findViewById(R.id.secondEmptyStar);
        thirdEmptyStar = (ImageView) findViewById(R.id.thirdEmptyStar);

        reviewsRecView = (RecyclerView) findViewById(R.id.reviewsRecView);

        addReviewRelLayout = (RelativeLayout) findViewById(R.id.addReviewRelLayout);
    }
}
